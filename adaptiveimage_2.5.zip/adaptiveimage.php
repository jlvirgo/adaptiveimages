<?php


defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.plugin.plugin');
if(!defined('DS')){	define('DS',DIRECTORY_SEPARATOR); }
class plgSystemAdaptiveImage extends JPlugin{
	
	function onAfterRoute(){
		$checktableextists = $this->checktableexists();
		if(!empty($checktableextists)) {
			if(JFactory::getApplication()->isAdmin()=='admin') {
				$this->copyfilename();
			}
		} else {
			$this->createtablevalue();
			if(JFactory::getApplication()->isAdmin()=='admin') {
				$this->copyfilename();
			}	
		}
	}
	function copyfilename(){
		$checktablevalueextists = $this->checktablevalues();
				if(!empty($checktablevalueextists)) {
					return;
				}
				jimport( 'joomla.filesystem.file' );
				$my_filetxt = JPATH_ROOT.'/htaccess.txt';
				$my_filedot = JPATH_ROOT.'/.htaccess';
				if(JFile::exists($my_filedot)) {
					$handle = fopen($my_filedot, 'a') or die('Cannot open file:  '.$my_filedot);
					$data = '<IfModule mod_rewrite.c>';
					$data .= "\n".'Options +FollowSymlinks';
					$data .= "\n".'RewriteEngine On';
							
					$data .= "\n".'# Adaptive-Images';
							
					$data .= "\n".'# Add any directories you wish to omit from the Adaptive-Images process on a new line, as follows:';
					$data .= "\n".'# RewriteCond %{REQUEST_URI} !some-directory';
					$data .= "\n".'# RewriteCond %{REQUEST_URI} !another-directory';
							
					$data .= "\n".'RewriteCond %{REQUEST_URI} !assets';
							
					$data .= "\n".'# Send any GIF, JPG, or PNG request that IS NOT stored inside one of the above directories';
					$data .= "\n".'# to adaptive-images.php so we can select appropriately sized versions';
					$data .= "\n".'RewriteRule \.(?:jpe?g|gif|png)$ adaptive-images.php';
							
					$data .= "\n".'# END Adaptive-Images';
					$data .= "\n".'</IfModule>'."\n";
					fwrite($handle, $data);
					fclose($handle);
					$src1 = JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'adaptiveimage'.DS.'ai-cookie.php';
					if(JFile::exists($src1)) {
						$dest1 = JPATH_ROOT.DS.'ai-cookie.php';
						JFile::copy($src1, $dest1);
					}
					$src2 = JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'adaptiveimage'.DS.'adaptive-images.php';
					if(JFile::exists($src2)) {
						$dest2 = JPATH_ROOT.DS.'adaptive-images.php';
						JFile::copy($src2, $dest2);	
					}
					$this->inserttablevalue();
				} else if(JFile::exists($my_filetxt)) {
					
					$handle = fopen($my_filetxt, 'a') or die('Cannot open file:  '.$my_filetxt);
					$data = '<IfModule mod_rewrite.c>';
					$data .= "\n".'Options +FollowSymlinks';
					$data .= "\n".'RewriteEngine On';
							
					$data .= "\n".'# Adaptive-Images';
							
					$data .= "\n".'# Add any directories you wish to omit from the Adaptive-Images process on a new line, as follows:';
					$data .= "\n".'# RewriteCond %{REQUEST_URI} !some-directory';
					$data .= "\n".'# RewriteCond %{REQUEST_URI} !another-directory';
							
					$data .= "\n".'RewriteCond %{REQUEST_URI} !assets';
							
					$data .= "\n".'# Send any GIF, JPG, or PNG request that IS NOT stored inside one of the above directories';
					$data .= "\n".'# to adaptive-images.php so we can select appropriately sized versions';
					$data .= "\n".'RewriteRule \.(?:jpe?g|gif|png)$ adaptive-images.php';
							
					$data .= "\n".'# END Adaptive-Images';
					$data .= "\n".'</IfModule>'."\n";
					fwrite($handle, $data);
					fclose($handle);
					
					$src1 = JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'adaptiveimage'.DS.'ai-cookie.php';
					if(JFile::exists($src1)) {
						$dest1 = JPATH_ROOT.DS.'ai-cookie.php';
						JFile::copy($src1, $dest1);
					}
					$src2 = JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'adaptiveimage'.DS.'adaptive-images.php';
					if(JFile::exists($src2)) {
						$dest2 = JPATH_ROOT.DS.'adaptive-images.php';
						JFile::copy($src2, $dest2);	
					}
					$this->inserttablevalue();
					
				}
	}
	function checktableexists(){
		$db = JFactory::getDBO();
		$app = JFactory::getApplication();
		$prefix = $app->getCfg('dbprefix');			
		$sql = "SHOW TABLES LIKE '".$prefix."plg_adaptive_image'";
		$db->setQuery($sql);
		return $db->LoadObjectList();
	}
	function inserttablevalue(){
		$db = JFactory::getDBO();
		$sql = "INSERT INTO #__plg_adaptive_image(id)VALUES(1)";
		$db->setQuery($sql);
		return $db->Query();
	}
	function createtablevalue(){
		$db = JFactory::getDBO();
		$sql = "CREATE TABLE IF NOT EXISTS `#__plg_adaptive_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";
		$db->setQuery($sql);
		return $db->Query();
	}
	function checktablevalues(){
		$db = JFactory::getDBO();
		$sql = "SELECT * FROM #__plg_adaptive_image";
		$db->setQuery($sql);
		return $db->LoadObject();
	}
	function plgSystemAdaptiveImage( &$subject, $params )
	{
		
		parent::__construct( $subject, $params );
		JPlugin::loadLanguage( 'plg_system_adaptiveimage', JPATH_ADMINISTRATOR );
		$this->jscode = $this->params->get('jscode');
		$this->stylecode = $this->params->get('stylecode');
		$this->loadjscode = $this->params->get('loadjscode');
		$this->loadstylecode = $this->params->get('loadstylecode');
		$this->jslib = $this->params->get('jslib');
		$this->csslib = $this->params->get('csslib');
		$this->loadjslib = $this->params->get('loadjslib');
		$this->loadcsslib = $this->params->get('loadcsslib');
		if ((empty ($this->jscode) && empty ($this->stylecode) && empty ($this->jslib) && empty ($this->csslib)) || (empty ($this->loadjscode) && empty ($this->loadstylecode) && empty($this->loadjslib) && empty ($this->loadcsslib))) return;
	}	
	
	function onBeforeCompileHead() {
		$loc = JFactory::getURI();
		$doc = JFactory::getDocument();
    $app = JFactory::getApplication();
		
		switch ($this->loadjslib) {
			case '1':
			if(!$app->isSite() || stripos($loc->getPath(),'/administrator/') === false) {
				if (!empty($this->jslib)) {
					$jslib = $this->fixLib($this->jslib);
					foreach ($jslib as $jslib) {
					$doc->addScript ($jslib);
					}
				}
			}
			break;
			
			case '2':
			if($app->isSite() || stripos($loc->getPath(),'/administrator/') !== false) { 
				if (!empty($this->jslib)) {
					$jslib = $this->fixLib($this->jslib);
					foreach ($jslib as $jslib) {
					$doc->addScript ($jslib);
					}
				}
			}
			break;
		
			case '3':
			if (!empty($this->jslib)) {
				$jslib = $this->fixLib($this->jslib);
				foreach ($jslib as $jslib) {
				$doc->addScript ($jslib);
				}	
			}
			break;
		}
		
		switch ($this->loadcsslib) {
			case '1':
			if(!$app->isSite() || stripos($loc->getPath(),'/administrator/') === false) {
				if (!empty($this->csslib)) {
					$csslib = $this->fixLib($this->csslib);
					foreach ($csslib as $csslib) {
					$doc->addStylesheet ($csslib);
					}
				}
			}
			break;
			
			case '2':
			if($app->isSite() || stripos($loc->getPath(),'/administrator/') !== false) { 
				if (!empty($this->csslib)) {
					$csslib = $this->fixLib($this->csslib);
					foreach ($csslib as $csslib) {
					$doc->addStylesheet ($csslib);
					}
				}
			}
			break;
		
			case '3':
			if (!empty($this->csslib)) {
				$csslib = $this->fixLib($this->csslib);
				foreach ($csslib as $csslib) {
				$doc->addStylesheet ($csslib);
				}
			}
			break;
		}
		
		switch ($this->loadjscode) {
			case '1':
			if(!$app->isSite() || stripos($loc->getPath(),'/administrator/') === false) {
				if (!empty($this->jscode)) {
				$doc->addScriptDeclaration($this->fixCode($this->jscode, 'jscode'));	
				}
			}
			break;
			
			case '2':
			if($app->isSite() || stripos($loc->getPath(),'/administrator/') !== false) { 
				if (!empty($this->jscode)) {
				$doc->addScriptDeclaration($this->fixCode($this->jscode, 'jscode'));	
				}
			}
			break;
		
			case '3':
			if (!empty($this->jscode)) {
			$doc->addScriptDeclaration($this->fixCode($this->jscode, 'jscode'));	
			}
			break;
		}
		
		
		switch ($this->loadstylecode) {
			case '1':
			if(!$app->isSite() || stripos($loc->getPath(),'/administrator/') === false) {
				if (!empty($this->stylecode)) {
				$doc->addStyleDeclaration($this->fixCode($this->stylecode, 'csscode'));	
				}
			}
			break;
			
			case '2':
			if($app->isSite() || stripos($loc->getPath(),'/administrator/') !== false) {
				if (!empty($this->stylecode)) {
				$doc->addStyleDeclaration($this->fixCode($this->stylecode, 'csscode'));	
				}
			}
			break;
		
			case '3':
			if (!empty($this->stylecode)) {
			$doc->addStyleDeclaration($this->fixCode($this->stylecode, 'csscode'));	
			}
			break;
		}
		
	}
	
	function fixLib($text) {
	$text = preg_replace ('/\s\s+/', ' ', trim($text));
	return explode(' ', $text);			
	}
	
	function fixCode($text, $type) {
	if ($type == 'jscode') {	
	$regex = "#<(\s*\/*)script(.*?)>#i";
	} elseif ($type =='csscode') {
	$regex = "#<(\s*\/*)style(.*?)>#i";
	} else {
	return;	
	}
	return preg_replace($regex, '', $text);
	}
}